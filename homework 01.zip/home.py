print("hello.Nick＾◡＾")
